(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_73f17af0._.js",
  "static/chunks/src_de8d2ade._.js"
],
    source: "dynamic"
});
