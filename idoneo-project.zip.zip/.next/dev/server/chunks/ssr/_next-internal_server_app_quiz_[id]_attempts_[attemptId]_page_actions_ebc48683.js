module.exports = [
"[project]/.next-internal/server/app/quiz/[id]/attempts/[attemptId]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_quiz_%5Bid%5D_attempts_%5BattemptId%5D_page_actions_ebc48683.js.map