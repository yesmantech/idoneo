module.exports = [
"[project]/.next-internal/server/app/quiz/[id]/official/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_quiz_%5Bid%5D_official_page_actions_5729fe0a.js.map