module.exports = [
"[project]/.next-internal/server/app/admin/subjects/new/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_admin_subjects_new_page_actions_cdeded19.js.map