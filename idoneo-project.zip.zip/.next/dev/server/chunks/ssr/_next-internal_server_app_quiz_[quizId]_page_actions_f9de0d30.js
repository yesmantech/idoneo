module.exports = [
"[project]/.next-internal/server/app/quiz/[quizId]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_quiz_%5BquizId%5D_page_actions_f9de0d30.js.map