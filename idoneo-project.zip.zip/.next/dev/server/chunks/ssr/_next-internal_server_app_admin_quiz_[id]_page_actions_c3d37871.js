module.exports = [
"[project]/.next-internal/server/app/admin/quiz/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_admin_quiz_%5Bid%5D_page_actions_c3d37871.js.map