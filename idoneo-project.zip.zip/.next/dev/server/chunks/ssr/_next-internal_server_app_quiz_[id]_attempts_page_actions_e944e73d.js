module.exports = [
"[project]/.next-internal/server/app/quiz/[id]/attempts/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_quiz_%5Bid%5D_attempts_page_actions_e944e73d.js.map