module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/lib/supabaseClient.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "supabase",
    ()=>supabase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/ssr/dist/module/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@supabase/ssr/dist/module/createBrowserClient.js [app-ssr] (ecmascript)");
'use client';
;
// Usiamo le ENV se ci sono, altrimenti fallback
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://yansgitqqrcovwukvpfm.supabase.co';
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlhbnNnaXRxcXJjb3Z3dWt2cGZtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQwNzQ5NzcsImV4cCI6MjA3OTY1MDk3N30.TbLgWITo0hvw1Vl9OY-Y_hbrU-y6cfKEnkMZhvG9bcQ';
const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createBrowserClient"])(SUPABASE_URL, SUPABASE_ANON_KEY);
}),
"[project]/src/app/admin/upload-csv/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AdminUploadCsvPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabaseClient$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabaseClient.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
const BUCKET = "question-images"; // cambia se il bucket ha altro nome
function normalizeImageName(original) {
    // stessa normalizzazione che useremo in upload multiplo
    return original.trim().replace(/\s+/g, "_").toLowerCase();
}
function AdminUploadCsvPage() {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [quizzes, setQuizzes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [subjects, setSubjects] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedQuizId, setSelectedQuizId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [selectedSubjectId, setSelectedSubjectId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [csvFile, setCsvFile] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [importing, setImporting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [importError, setImportError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [importSuccess, setImportSuccess] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    // Bulk immagini
    const [imageFiles, setImageFiles] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [uploadingImages, setUploadingImages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [imageMsg, setImageMsg] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [imageErr, setImageErr] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const loadQuizzes = async ()=>{
            const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabaseClient$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("quizzes").select("*").order("created_at", {
                ascending: false
            });
            if (error) {
                console.error("Errore caricando quizzes:", error);
                return;
            }
            setQuizzes(data || []);
        };
        loadQuizzes();
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const loadSubjects = async ()=>{
            if (!selectedQuizId) {
                setSubjects([]);
                setSelectedSubjectId("");
                return;
            }
            const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabaseClient$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("subjects").select("*").eq("quiz_id", selectedQuizId).order("created_at", {
                ascending: true
            });
            if (error) {
                console.error("Errore caricando subjects:", error);
                setSubjects([]);
                setSelectedSubjectId("");
                return;
            }
            const list = data || [];
            setSubjects(list);
            if (list.length > 0) {
                setSelectedSubjectId(list[0].id);
            } else {
                setSelectedSubjectId("");
            }
        };
        loadSubjects();
    }, [
        selectedQuizId
    ]);
    const handleCsvFileChange = (e)=>{
        const f = e.target.files?.[0] ?? null;
        setCsvFile(f);
        setImportError(null);
        setImportSuccess(null);
    };
    const parseCsv = async (file)=>{
        const text = await file.text();
        const lines = text.split(/\r?\n/).filter((l)=>l.trim().length > 0);
        if (lines.length < 2) {
            throw new Error("CSV vuoto o senza righe di dati.");
        }
        const headerLine = lines[0];
        const headers = headerLine.split(",").map((h)=>h.trim().replace(/^"|"$/g, ""));
        const required = [
            "question_text",
            "option_a",
            "option_b",
            "option_c",
            "option_d",
            "correct_option"
        ];
        for (const r of required){
            if (!headers.includes(r)) {
                throw new Error(`Colonna obbligatoria mancante: "${r}". Header trovati: ${headers.join(", ")}`);
            }
        }
        const idx = (name)=>headers.indexOf(name);
        const rows = [];
        for(let i = 1; i < lines.length; i++){
            const raw = lines[i];
            if (!raw.trim()) continue;
            const cols = raw.split(",").map((c)=>c.trim().replace(/^"|"$/g, ""));
            const row = {
                question_text: cols[idx("question_text")] ?? "",
                option_a: cols[idx("option_a")] ?? "",
                option_b: cols[idx("option_b")] ?? "",
                option_c: cols[idx("option_c")] ?? "",
                option_d: cols[idx("option_d")] ?? "",
                correct_option: (cols[idx("correct_option")] ?? "").toLowerCase()
            };
            if (idx("subject_id") >= 0) {
                const sid = cols[idx("subject_id")]?.trim();
                if (sid) row.subject_id = sid;
            }
            if (idx("image_name") >= 0) {
                const iname = cols[idx("image_name")]?.trim();
                if (iname) row.image_name = iname;
            } else if (idx("image") >= 0) {
                const iname = cols[idx("image")]?.trim();
                if (iname) row.image_name = iname;
            }
            rows.push(row);
        }
        return rows;
    };
    const handleImport = async ()=>{
        if (!selectedQuizId) {
            setImportError("Seleziona prima un concorso.");
            return;
        }
        if (!csvFile) {
            setImportError("Seleziona prima un file CSV.");
            return;
        }
        setImporting(true);
        setImportError(null);
        setImportSuccess(null);
        try {
            const parsed = await parseCsv(csvFile);
            if (parsed.length === 0) {
                throw new Error("Nessuna riga valida trovata nel CSV.");
            }
            // preparazione dei record per insert
            const toInsert = parsed.map((row, idx)=>{
                let subjectId = row.subject_id?.trim();
                if (!subjectId && selectedSubjectId) {
                    subjectId = selectedSubjectId;
                }
                if (!subjectId) {
                    console.warn(`Riga ${idx + 2}: subject_id mancante e nessuna materia selezionata. La domanda verrà saltata.`);
                }
                // normalizziamo correct_option: a/b/c/d
                const corr = row.correct_option?.toLowerCase();
                if (![
                    "a",
                    "b",
                    "c",
                    "d"
                ].includes(corr)) {
                    console.warn(`Riga ${idx + 2}: correct_option non valida "${row.correct_option}". Deve essere a, b, c o d.`);
                }
                // costruiamo image_url se image_name presente
                let imageUrl = null;
                if (row.image_name) {
                    const normalizedName = normalizeImageName(row.image_name);
                    const { data: urlData } = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabaseClient$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].storage.from(BUCKET).getPublicUrl(normalizedName);
                    imageUrl = urlData?.publicUrl || null;
                }
                return {
                    quiz_id: selectedQuizId,
                    subject_id: subjectId ?? null,
                    text: row.question_text,
                    option_a: row.option_a,
                    option_b: row.option_b,
                    option_c: row.option_c,
                    option_d: row.option_d,
                    correct_option: corr,
                    image_url: imageUrl,
                    is_archived: false
                };
            });
            const valid = toInsert.filter((q)=>q.subject_id && q.text && q.option_a && q.option_b && q.option_c && q.option_d && q.correct_option);
            if (valid.length === 0) {
                throw new Error("Nessuna riga valida da importare. Controlla subject_id, opzioni e correct_option.");
            }
            const { error: insertError } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabaseClient$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("questions").insert(valid);
            if (insertError) {
                console.error("Errore durante l'inserimento delle domande:", insertError);
                setImportError(`Errore durante l'inserimento delle domande: ${insertError.message}`);
                return;
            }
            setImportSuccess(`Import completato: ${valid.length} domande inserite con successo.`);
        } catch (err) {
            console.error("Errore import CSV:", err);
            setImportError(err?.message || "Errore durante l'import del CSV. Controlla il formato del file.");
        } finally{
            setImporting(false);
        }
    };
    const handleImageFilesChange = (e)=>{
        setImageFiles(e.target.files ?? null);
        setImageMsg(null);
        setImageErr(null);
    };
    const handleUploadImages = async ()=>{
        if (!imageFiles || imageFiles.length === 0) {
            setImageErr("Seleziona uno o più file immagine.");
            return;
        }
        setUploadingImages(true);
        setImageErr(null);
        setImageMsg(null);
        try {
            let uploaded = 0;
            let skipped = 0;
            let failed = 0;
            for(let i = 0; i < imageFiles.length; i++){
                const file = imageFiles[i];
                const normalizedName = normalizeImageName(file.name);
                const { data: existing, error: listError } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabaseClient$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].storage.from(BUCKET).list("", {
                    search: normalizedName,
                    limit: 1
                });
                if (listError) {
                    console.warn("Errore in list per bulk upload:", listError);
                }
                if (existing && existing.length > 0) {
                    // già esiste un file con questo nome → per ora lo saltiamo
                    console.log(`File ${normalizedName} già presente nel bucket, lo salto.`);
                    skipped++;
                    continue;
                }
                const { error: uploadError } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabaseClient$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].storage.from(BUCKET).upload(normalizedName, file, {
                    cacheControl: "3600",
                    upsert: false
                });
                if (uploadError) {
                    console.error("Errore upload immagine:", uploadError);
                    failed++;
                } else {
                    uploaded++;
                }
            }
            setImageMsg(`Upload completato. Caricate: ${uploaded}, già presenti: ${skipped}, fallite: ${failed}.` + "\nNel CSV usa la colonna image_name con il nome normalizzato (es. 'figura1.png' → 'figura1.png', 'Figura 1.PNG' → 'figura_1.png').");
        } catch (err) {
            console.error("Errore bulk upload immagini:", err);
            setImageErr(err?.message || "Errore durante l'upload delle immagini.");
        } finally{
            setUploadingImages(false);
        }
    };
    const anySelectedQuiz = quizzes.find((q)=>q.id === selectedQuizId);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-slate-950 text-white",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto max-w-5xl px-4 py-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: ()=>router.push("/admin"),
                    className: "mb-4 text-xs text-slate-300 hover:text-slate-100",
                    children: "← Torna alla Admin Dashboard"
                }, void 0, false, {
                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                    lineNumber: 369,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-xl font-semibold mb-1",
                    children: "Import domande da CSV"
                }, void 0, false, {
                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                    lineNumber: 376,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-xs text-slate-300 mb-4",
                    children: [
                        "Seleziona concorso e (opzionalmente) una materia, carica un file CSV con le domande. Puoi anche caricare in bulk le immagini e collegarle alle domande usando la colonna ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                            children: "image_name"
                        }, void 0, false, {
                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                            lineNumber: 380,
                            columnNumber: 42
                        }, this),
                        "."
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                    lineNumber: 377,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "rounded-2xl border border-slate-800 bg-slate-900/70 p-4 mb-4 text-xs",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-sm font-semibold mb-2",
                            children: "Bulk upload immagini"
                        }, void 0, false, {
                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                            lineNumber: 385,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-[11px] text-slate-300 mb-2",
                            children: [
                                "Tutte le immagini vengono caricate nel bucket",
                                " ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                    children: BUCKET
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                    lineNumber: 388,
                                    columnNumber: 13
                                }, this),
                                " con nome normalizzato (minuscole, spazi →",
                                " ",
                                "underscore). Nel CSV puoi usare la colonna",
                                " ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                    children: "image_name"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                    lineNumber: 390,
                                    columnNumber: 13
                                }, this),
                                " con lo stesso nome."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                            lineNumber: 386,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "file",
                                    accept: "image/*",
                                    multiple: true,
                                    onChange: handleImageFilesChange,
                                    className: "text-[11px]"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                    lineNumber: 393,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: handleUploadImages,
                                    disabled: uploadingImages || !imageFiles || imageFiles.length === 0,
                                    className: "w-full rounded-md bg-sky-600 px-3 py-2 text-xs font-medium text-white hover:bg-sky-500 disabled:opacity-50 disabled:cursor-not-allowed",
                                    children: uploadingImages ? "Caricamento immagini…" : "Carica immagini selezionate"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                    lineNumber: 400,
                                    columnNumber: 13
                                }, this),
                                imageErr && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[11px] text-red-400 whitespace-pre-line",
                                    children: imageErr
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                    lineNumber: 411,
                                    columnNumber: 15
                                }, this),
                                imageMsg && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[11px] text-emerald-400 whitespace-pre-line",
                                    children: imageMsg
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                    lineNumber: 416,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[10px] text-slate-400",
                                    children: [
                                        "Esempio: carichi ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                            children: "Figura 1.PNG"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                            lineNumber: 421,
                                            columnNumber: 32
                                        }, this),
                                        " → viene salvata come",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                            children: "figura_1.png"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                            lineNumber: 422,
                                            columnNumber: 15
                                        }, this),
                                        ". Nel CSV usa",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                            children: "image_name"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                            lineNumber: 423,
                                            columnNumber: 15
                                        }, this),
                                        " = ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                            children: "figura_1.png"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                            lineNumber: 423,
                                            columnNumber: 41
                                        }, this),
                                        "."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                    lineNumber: 420,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                            lineNumber: 392,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                    lineNumber: 384,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "rounded-2xl border border-slate-800 bg-slate-900/70 p-4 text-xs",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-sm font-semibold mb-2",
                            children: "Import domande da CSV"
                        }, void 0, false, {
                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                            lineNumber: 430,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block text-slate-200 mb-1",
                                    children: "Concorso (quiz)"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                    lineNumber: 436,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: selectedQuizId,
                                    onChange: (e)=>setSelectedQuizId(e.target.value),
                                    className: "w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-xs",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "",
                                            children: "Seleziona un concorso…"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                            lineNumber: 444,
                                            columnNumber: 15
                                        }, this),
                                        quizzes.map((q)=>{
                                            const anyQ = q;
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: q.id,
                                                children: [
                                                    anyQ.title || "Senza titolo",
                                                    " ",
                                                    anyQ.year ? `(${anyQ.year})` : ""
                                                ]
                                            }, q.id, true, {
                                                fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                                lineNumber: 448,
                                                columnNumber: 19
                                            }, this);
                                        })
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                    lineNumber: 439,
                                    columnNumber: 13
                                }, this),
                                anySelectedQuiz && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-1 text-[11px] text-slate-400",
                                    children: [
                                        "Domande ufficiali:",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-mono text-slate-100",
                                            children: anySelectedQuiz.total_questions ?? "—"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                            lineNumber: 458,
                                            columnNumber: 17
                                        }, this),
                                        " ",
                                        "· Tempo:",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-mono text-slate-100",
                                            children: [
                                                anySelectedQuiz.time_limit ?? "—",
                                                " min"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                            lineNumber: 462,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                    lineNumber: 456,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                            lineNumber: 435,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block text-slate-200 mb-1",
                                    children: 'Materia (opzionale, usata se nel CSV manca "subject_id")'
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                    lineNumber: 471,
                                    columnNumber: 13
                                }, this),
                                selectedQuizId ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: selectedSubjectId,
                                    onChange: (e)=>setSelectedSubjectId(e.target.value),
                                    className: "w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-xs",
                                    children: [
                                        subjects.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "",
                                            children: "Nessuna materia disponibile"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                            lineNumber: 481,
                                            columnNumber: 19
                                        }, this),
                                        subjects.map((s)=>{
                                            const anyS = s;
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: s.id,
                                                children: [
                                                    anyS.name || "Materia",
                                                    " ",
                                                    anyS.code ? `(${anyS.code})` : ""
                                                ]
                                            }, s.id, true, {
                                                fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                                lineNumber: 486,
                                                columnNumber: 21
                                            }, this);
                                        })
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                    lineNumber: 475,
                                    columnNumber: 15
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[11px] text-slate-400",
                                    children: "Seleziona prima un concorso per vedere le materie disponibili."
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                    lineNumber: 494,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                            lineNumber: 470,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block text-slate-200 mb-1",
                                    children: "File CSV"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                    lineNumber: 502,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "file",
                                    accept: ".csv,text/csv",
                                    onChange: handleCsvFileChange,
                                    className: "text-[11px]"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                    lineNumber: 503,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-1 text-[10px] text-slate-400",
                                    children: [
                                        "Formato colonne obbligatorie:",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                            children: "question_text, option_a, option_b, option_c, option_d, correct_option"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                            lineNumber: 511,
                                            columnNumber: 15
                                        }, this),
                                        ". Opzionali:",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                            children: "subject_id, image_name"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                            lineNumber: 516,
                                            columnNumber: 15
                                        }, this),
                                        ". Se",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                            children: "subject_id"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                            lineNumber: 517,
                                            columnNumber: 15
                                        }, this),
                                        " manca, viene usata la materia selezionata sopra."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                                    lineNumber: 509,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                            lineNumber: 501,
                            columnNumber: 11
                        }, this),
                        importError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-[11px] text-red-400 mb-1 whitespace-pre-line",
                            children: importError
                        }, void 0, false, {
                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                            lineNumber: 523,
                            columnNumber: 13
                        }, this),
                        importSuccess && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-[11px] text-emerald-400 mb-1 whitespace-pre-line",
                            children: importSuccess
                        }, void 0, false, {
                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                            lineNumber: 528,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: handleImport,
                            disabled: importing || !csvFile || !selectedQuizId,
                            className: "mt-1 w-full rounded-md bg-emerald-600 px-4 py-2 text-xs font-medium text-white hover:bg-emerald-500 disabled:opacity-60 disabled:cursor-not-allowed",
                            children: importing ? "Import in corso…" : "Importa domande da CSV"
                        }, void 0, false, {
                            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                            lineNumber: 533,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/admin/upload-csv/page.tsx",
                    lineNumber: 429,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/admin/upload-csv/page.tsx",
            lineNumber: 368,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/admin/upload-csv/page.tsx",
        lineNumber: 367,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__144ebc47._.js.map