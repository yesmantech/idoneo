module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/lib/supabaseClient.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "supabase",
    ()=>supabase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/ssr/dist/module/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@supabase/ssr/dist/module/createBrowserClient.js [app-ssr] (ecmascript)");
'use client';
;
// Usiamo le ENV se ci sono, altrimenti fallback
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://yansgitqqrcovwukvpfm.supabase.co';
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlhbnNnaXRxcXJjb3Z3dWt2cGZtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQwNzQ5NzcsImV4cCI6MjA3OTY1MDk3N30.TbLgWITo0hvw1Vl9OY-Y_hbrU-y6cfKEnkMZhvG9bcQ';
const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createBrowserClient"])(SUPABASE_URL, SUPABASE_ANON_KEY);
}),
"[project]/src/app/quiz/[id]/custom/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CustomQuizPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabaseClient$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabaseClient.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function shuffle(arr) {
    const copy = [
        ...arr
    ];
    for(let i = copy.length - 1; i > 0; i--){
        const j = Math.floor(Math.random() * (i + 1));
        const temp = copy[i];
        copy[i] = copy[j];
        copy[j] = temp;
    }
    return copy;
}
function formatTime(seconds) {
    if (seconds === null || seconds < 0) return "--:--";
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    const mm = m.toString().padStart(2, "0");
    const ss = s.toString().padStart(2, "0");
    return `${mm}:${ss}`;
}
function CustomQuizPage({ params }) {
    const { id: quizId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["use"])(params);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const paramModeRaw = searchParams.get("mode");
    const paramMode = paramModeRaw === "errors_recent" || paramModeRaw === "most_wrong" ? paramModeRaw : "standard";
    const paramMinutes = searchParams.get("minutes");
    const paramSubjects = searchParams.get("subjects");
    const paramDist = searchParams.get("dist");
    const paramAttempts = searchParams.get("attempts");
    const paramLimit = searchParams.get("limit");
    const selectedSubjectIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>paramSubjects ? paramSubjects.split(",").map((s)=>s.trim()).filter(Boolean) : [], [
        paramSubjects
    ]);
    const distributionMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const map = {};
        if (!paramDist) return map;
        const chunks = paramDist.split(",").map((c)=>c.trim());
        chunks.forEach((chunk)=>{
            const [id, raw] = chunk.split(":");
            if (!id || !raw) return;
            const n = Number.parseInt(raw, 10);
            if (!Number.isFinite(n) || n <= 0) return;
            map[id] = n;
        });
        return map;
    }, [
        paramDist
    ]);
    const [quiz, setQuiz] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [subjects, setSubjects] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [questions, setQuestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedQuestions, setSelectedQuestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [currentIndex, setCurrentIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [answers, setAnswers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    const [finished, setFinished] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [result, setResult] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [subjectBreakdown, setSubjectBreakdown] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [customTimeLimit, setCustomTimeLimit] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [remainingSeconds, setRemainingSeconds] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [timerActive, setTimerActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const load = async ()=>{
            setLoading(true);
            setError(null);
            try {
                const needAttempts = paramMode === "errors_recent" || paramMode === "most_wrong";
                const recentAttemptsLimit = (()=>{
                    const n = paramAttempts ? Number.parseInt(paramAttempts, 10) : NaN;
                    if (Number.isFinite(n) && n > 0) return n;
                    return 10; // default: ultimi 10 tentativi per "solo errori"
                })();
                const mostWrongLimit = (()=>{
                    const n = paramLimit ? Number.parseInt(paramLimit, 10) : NaN;
                    if (Number.isFinite(n) && n > 0) return n;
                    return 50; // default: max 50 domande "più sbagliate"
                })();
                const [{ data: quizData, error: quizError }, { data: subjectsData, error: subjectsError }, { data: questionsData, error: questionsError }, attemptsRes] = await Promise.all([
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabaseClient$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("quizzes").select("*").eq("id", quizId).single(),
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabaseClient$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("subjects").select("*").eq("quiz_id", quizId),
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabaseClient$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("questions").select("*").eq("quiz_id", quizId),
                    needAttempts ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabaseClient$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("quiz_attempts").select("id, answers, finished_at").eq("quiz_id", quizId).order("finished_at", {
                        ascending: false
                    }).limit(paramMode === "errors_recent" ? recentAttemptsLimit : mostWrongLimit) : Promise.resolve({
                        data: null,
                        error: null
                    })
                ]);
                if (quizError || subjectsError || questionsError) {
                    throw quizError || subjectsError || questionsError;
                }
                const attemptsError = "error" in attemptsRes && attemptsRes.error ? attemptsRes.error : null;
                if (attemptsError) {
                    throw attemptsError;
                }
                const attemptsData = attemptsRes.data || [];
                const qz = quizData;
                const sbj = subjectsData || [];
                const qs = questionsData || [];
                // domande attive
                let activeQuestions = qs.filter((q)=>!q.is_archived);
                // filtra per materie selezionate (se presenti)
                if (selectedSubjectIds.length > 0) {
                    activeQuestions = activeQuestions.filter((q)=>q.subject_id && selectedSubjectIds.includes(q.subject_id));
                }
                if (activeQuestions.length === 0) {
                    setError(selectedSubjectIds.length > 0 ? "Non ci sono domande attive nelle materie selezionate. Modifica le materie o aggiungi domande dall'area admin." : "Non ci sono domande attive per questo concorso. Aggiungile dall'area admin.");
                    setLoading(false);
                    return;
                }
                const activeById = {};
                activeQuestions.forEach((q)=>{
                    activeById[q.id] = q;
                });
                if (needAttempts && attemptsData.length === 0) {
                    setError("Non ci sono ancora tentativi registrati per questo concorso. Fai prima almeno un quiz ufficiale per usare la modalità basata sugli errori.");
                    setLoading(false);
                    return;
                }
                const selected = [];
                if (paramMode === "standard") {
                    if (Object.keys(distributionMap).length === 0) {
                        setError("Non è stata definita alcuna distribuzione per il quiz personalizzato. Torna alla pagina concorso e imposta il numero di domande per materia.");
                        setLoading(false);
                        return;
                    }
                    const bySubject = {};
                    activeQuestions.forEach((q)=>{
                        const sid = q.subject_id;
                        if (!sid) return;
                        if (!bySubject[sid]) bySubject[sid] = [];
                        bySubject[sid].push(q);
                    });
                    Object.entries(distributionMap).forEach(([subjectId, count])=>{
                        const pool = bySubject[subjectId] || [];
                        if (pool.length === 0) return;
                        const n = Math.min(count, pool.length);
                        const subset = shuffle(pool).slice(0, n);
                        subset.forEach((q)=>selected.push(q));
                    });
                } else if (paramMode === "errors_recent") {
                    // SOLO ERRORI RECENTI: domande sbagliate negli ultimi N tentativi (senza duplicati), in ordine di recenza
                    const seen = new Set();
                    const maxQuestions = mostWrongLimit || 100; // usiamo mostWrongLimit come cap generico
                    outer: for (const att of attemptsData){
                        const arr = att.answers || [];
                        if (!Array.isArray(arr)) continue;
                        for (const ans of arr){
                            if (!ans) continue;
                            const qid = ans.question_id;
                            if (!qid) continue;
                            if (seen.has(qid)) continue;
                            if (ans.is_correct) continue;
                            const q = activeById[qid];
                            if (!q) continue; // domanda non attiva o materia esclusa
                            seen.add(qid);
                            selected.push(q);
                            if (selected.length >= maxQuestions) {
                                break outer;
                            }
                        }
                    }
                } else if (paramMode === "most_wrong") {
                    // DOMANDE PIÙ SBAGLIATE: calcola quante volte hai sbagliato ogni domanda
                    const statsMap = {};
                    for (const att of attemptsData){
                        const arr = att.answers || [];
                        if (!Array.isArray(arr)) continue;
                        for (const ans of arr){
                            if (!ans) continue;
                            const qid = ans.question_id;
                            if (!qid) continue;
                            if (!activeById[qid]) continue; // ignoriamo domande non attive o fuori materie
                            if (!statsMap[qid]) {
                                statsMap[qid] = {
                                    wrong: 0,
                                    total: 0
                                };
                            }
                            statsMap[qid].total += 1;
                            if (!ans.is_correct) {
                                statsMap[qid].wrong += 1;
                            }
                        }
                    }
                    const limit = (()=>{
                        const n = paramLimit ? Number.parseInt(paramLimit, 10) : NaN;
                        if (Number.isFinite(n) && n > 0) return n;
                        return 50;
                    })();
                    const sorted = Object.entries(statsMap).filter(([, st])=>st.wrong > 0).sort((a, b)=>b[1].wrong - a[1].wrong);
                    for (const [qid, st] of sorted.slice(0, limit)){
                        if (!activeById[qid]) continue;
                        selected.push(activeById[qid]);
                    }
                }
                if (selected.length === 0) {
                    setError(paramMode === "standard" ? "Non è stato possibile generare il quiz con la distribuzione scelta. Controlla che ci siano domande per le materie selezionate." : "Non ci sono domande sufficienti dagli errori registrati per generare il quiz. Prova a fare altri quiz ufficiali.");
                    setLoading(false);
                    return;
                }
                const initialAnswers = {};
                selected.forEach((q)=>{
                    initialAnswers[q.id] = null;
                });
                const requestedMinutes = paramMinutes ? Number.parseInt(paramMinutes, 10) : NaN;
                const anyQuiz = qz;
                const minutes = Number.isFinite(requestedMinutes) && requestedMinutes > 0 ? requestedMinutes : anyQuiz.time_limit || null;
                setQuiz(qz);
                setSubjects(sbj);
                setQuestions(activeQuestions);
                setSelectedQuestions(selected);
                setAnswers(initialAnswers);
                setCustomTimeLimit(minutes);
                if (minutes) {
                    setRemainingSeconds(minutes * 60);
                    setTimerActive(true);
                }
            } catch (err) {
                console.error(err);
                setError("Errore nel caricamento del quiz personalizzato.");
            } finally{
                setLoading(false);
            }
        };
        load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        quizId,
        paramMinutes,
        paramMode,
        paramSubjects,
        paramDist,
        paramAttempts,
        paramLimit
    ]);
    const anyQuiz = quiz || {};
    const subjectsMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const map = {};
        subjects.forEach((s)=>{
            map[s.id] = s;
        });
        return map;
    }, [
        subjects
    ]);
    const totalQuestions = selectedQuestions.length;
    const currentQuestion = selectedQuestions[currentIndex];
    // timer countdown
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!timerActive) return;
        if (finished) return;
        if (remainingSeconds === null) return;
        if (remainingSeconds <= 0) return;
        const id = setInterval(()=>{
            setRemainingSeconds((prev)=>{
                if (prev === null || prev <= 0) return prev;
                return prev - 1;
            });
        }, 1000);
        return ()=>clearInterval(id);
    }, [
        timerActive,
        finished,
        remainingSeconds
    ]);
    // auto finish quando tempo finisce
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!timerActive) return;
        if (finished) return;
        if (remainingSeconds === null) return;
        if (remainingSeconds > 0) return;
        handleFinish(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        remainingSeconds,
        timerActive,
        finished
    ]);
    const handleSelectAnswer = (questionId, option)=>{
        setAnswers((prev)=>({
                ...prev,
                [questionId]: option
            }));
    };
    const handleNext = ()=>{
        if (currentIndex < totalQuestions - 1) {
            setCurrentIndex((i)=>i + 1);
        }
    };
    const handlePrev = ()=>{
        if (currentIndex > 0) {
            setCurrentIndex((i)=>i - 1);
        }
    };
    const handleFinish = (auto = false)=>{
        if (!quiz) return;
        if (finished) return;
        let correct = 0;
        let wrong = 0;
        let blank = 0;
        const sbMap = {};
        const ensureStat = (subjectId)=>{
            const key = subjectId || "_none";
            if (!sbMap[key]) {
                const name = subjectId && subjectsMap[subjectId] ? subjectsMap[subjectId].name || "Materia" : "Senza materia";
                sbMap[key] = {
                    subjectId: key,
                    name,
                    total: 0,
                    correct: 0,
                    wrong: 0,
                    blank: 0
                };
            }
            return sbMap[key];
        };
        selectedQuestions.forEach((q)=>{
            const chosen = answers[q.id];
            let chosenText = null;
            if (chosen === "A") chosenText = q.option_a;
            else if (chosen === "B") chosenText = q.option_b;
            else if (chosen === "C") chosenText = q.option_c;
            else if (chosen === "D") chosenText = q.option_d;
            const correctAnswer = (q.correct_answer || "").trim() || null;
            const stat = ensureStat(q.subject_id);
            stat.total += 1;
            if (!chosen) {
                blank++;
                stat.blank += 1;
            } else {
                if (chosenText && correctAnswer && chosenText.trim() === correctAnswer) {
                    correct++;
                    stat.correct += 1;
                } else {
                    wrong++;
                    stat.wrong += 1;
                }
            }
        });
        const pc = anyQuiz.points_correct ?? 1;
        const pw = anyQuiz.points_wrong ?? -0.33;
        const pb = anyQuiz.points_blank ?? 0;
        const score = correct * pc + wrong * pw + blank * pb;
        setResult({
            correct,
            wrong,
            blank,
            score
        });
        setSubjectBreakdown(Object.values(sbMap));
        setFinished(true);
        setTimerActive(false);
        if (auto) {
            console.log("Quiz personalizzato terminato per tempo scaduto.");
        }
    };
    const answeredCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>Object.values(answers).filter((v)=>v !== null && v !== undefined).length, [
        answers
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-slate-950 text-white",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto max-w-5xl px-4 py-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: ()=>router.push(`/quiz/${quizId}`),
                    className: "mb-4 text-xs text-slate-300 hover:text-slate-100",
                    children: "← Torna alla pagina concorso"
                }, void 0, false, {
                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                    lineNumber: 503,
                    columnNumber: 9
                }, this),
                loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-sm text-slate-300",
                    children: "Preparazione quiz personalizzato…"
                }, void 0, false, {
                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                    lineNumber: 511,
                    columnNumber: 11
                }, this) : error ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-sm text-red-400",
                    children: error
                }, void 0, false, {
                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                    lineNumber: 515,
                    columnNumber: 11
                }, this) : !quiz ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-sm text-red-400",
                    children: "Concorso non trovato. Controlla l'URL."
                }, void 0, false, {
                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                    lineNumber: 517,
                    columnNumber: 11
                }, this) : totalQuestions === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-sm text-slate-300",
                    children: "Non ci sono domande sufficienti per generare il quiz personalizzato."
                }, void 0, false, {
                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                    lineNumber: 521,
                    columnNumber: 11
                }, this) : finished && result ? // RISULTATO
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "rounded-2xl border border-slate-800 bg-slate-900/70 p-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "text-lg font-semibold mb-1",
                                    children: "Risultato quiz personalizzato"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                    lineNumber: 529,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs text-slate-300 mb-3",
                                    children: [
                                        anyQuiz.title || "Concorso",
                                        " · Domande: ",
                                        totalQuestions,
                                        " ·",
                                        " ",
                                        "Risposte date: ",
                                        answeredCount,
                                        paramMode !== "standard" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                " ",
                                                "· Modalità:",
                                                " ",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-slate-100",
                                                    children: paramMode === "errors_recent" ? "solo errori recenti" : "domande più sbagliate"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                    lineNumber: 539,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                    lineNumber: 532,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid gap-4 md:grid-cols-4 text-xs",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "rounded-lg bg-slate-900 border border-emerald-600/60 p-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-slate-300 mb-1",
                                                    children: "Corrette"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                    lineNumber: 550,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xl font-semibold text-emerald-400",
                                                    children: result.correct
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                    lineNumber: 551,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                            lineNumber: 549,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "rounded-lg bg-slate-900 border border-rose-600/60 p-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-slate-300 mb-1",
                                                    children: "Errate"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                    lineNumber: 556,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xl font-semibold text-rose-400",
                                                    children: result.wrong
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                    lineNumber: 557,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                            lineNumber: 555,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "rounded-lg bg-slate-900 border border-slate-600/60 p-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-slate-300 mb-1",
                                                    children: "Omesse"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                    lineNumber: 562,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xl font-semibold text-slate-100",
                                                    children: result.blank
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                    lineNumber: 563,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                            lineNumber: 561,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "rounded-lg bg-slate-900 border border-sky-600/60 p-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-slate-300 mb-1",
                                                    children: "Punteggio"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                    lineNumber: 568,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xl font-semibold text-sky-400",
                                                    children: result.score.toFixed(2)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                    lineNumber: 569,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                            lineNumber: 567,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                    lineNumber: 548,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                            lineNumber: 528,
                            columnNumber: 13
                        }, this),
                        subjectBreakdown.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "rounded-2xl border border-slate-800 bg-slate-900/70 p-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-sm font-semibold mb-2",
                                    children: "Dettaglio per materia"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                    lineNumber: 579,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "overflow-x-auto text-xs",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                        className: "w-full",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                                className: "text-slate-300 border-b border-slate-800",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                            className: "text-left py-1 pr-2",
                                                            children: "Materia"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                            lineNumber: 586,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                            className: "text-left py-1 px-2",
                                                            children: "Domande"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                            lineNumber: 587,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                            className: "text-left py-1 px-2",
                                                            children: "Corrette"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                            lineNumber: 588,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                            className: "text-left py-1 px-2",
                                                            children: "Errate"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                            lineNumber: 589,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                            className: "text-left py-1 px-2",
                                                            children: "Omesse"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                            lineNumber: 590,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                    lineNumber: 585,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                lineNumber: 584,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                                children: subjectBreakdown.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                        className: "border-t border-slate-800",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "py-1 pr-2 text-slate-100",
                                                                children: s.name
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                                lineNumber: 599,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "py-1 px-2",
                                                                children: s.total
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                                lineNumber: 602,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "py-1 px-2 text-emerald-400",
                                                                children: s.correct
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                                lineNumber: 603,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "py-1 px-2 text-rose-400",
                                                                children: s.wrong
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                                lineNumber: 606,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "py-1 px-2 text-slate-200",
                                                                children: s.blank
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                                lineNumber: 609,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, s.subjectId, true, {
                                                        fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                        lineNumber: 595,
                                                        columnNumber: 25
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                lineNumber: 593,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                        lineNumber: 583,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                    lineNumber: 582,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                            lineNumber: 578,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>{
                                setFinished(false);
                                setResult(null);
                                setCurrentIndex(0);
                            },
                            className: "rounded-md bg-slate-800 px-4 py-2 text-sm font-medium text-white",
                            children: "Rivedi le domande"
                        }, void 0, false, {
                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                            lineNumber: 620,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                    lineNumber: 527,
                    columnNumber: 11
                }, this) : // QUIZ IN CORSO
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "rounded-2xl border border-slate-800 bg-slate-900/70 p-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "text-lg font-semibold",
                                    children: [
                                        "Quiz personalizzato – ",
                                        anyQuiz.title || "Concorso"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                    lineNumber: 635,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs text-slate-300 mt-1",
                                    children: [
                                        "Domanda ",
                                        currentIndex + 1,
                                        " di ",
                                        totalQuestions,
                                        " · Risposte date: ",
                                        answeredCount
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                    lineNumber: 638,
                                    columnNumber: 15
                                }, this),
                                customTimeLimit && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[11px] text-slate-200 mt-1 flex items-center gap-2",
                                    children: [
                                        "Tempo: ",
                                        customTimeLimit,
                                        " minuti",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "inline-flex items-center rounded-full bg-slate-900 px-2 py-0.5 font-mono text-[11px] border border-slate-700",
                                            children: formatTime(remainingSeconds)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                            lineNumber: 645,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                    lineNumber: 643,
                                    columnNumber: 17
                                }, this),
                                paramMode !== "standard" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[11px] text-slate-400 mt-1",
                                    children: [
                                        "Modalità:",
                                        " ",
                                        paramMode === "errors_recent" ? "solo errori recenti (domande sbagliate negli ultimi tentativi)" : "domande più sbagliate (quelle dove hai sbagliato più volte)"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                    lineNumber: 651,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                            lineNumber: 634,
                            columnNumber: 13
                        }, this),
                        currentQuestion && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "rounded-2xl border border-slate-800 bg-slate-900/70 p-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mb-2 text-[11px] text-slate-400",
                                    children: currentQuestion.subject_id && subjectsMap[currentQuestion.subject_id] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                        children: [
                                            "Materia:",
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-slate-200",
                                                children: subjectsMap[currentQuestion.subject_id].name
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                lineNumber: 667,
                                                columnNumber: 25
                                            }, this)
                                        ]
                                    }, void 0, true)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                    lineNumber: 662,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-slate-100 mb-3",
                                    children: currentQuestion.text
                                }, void 0, false, {
                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                    lineNumber: 674,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-2 text-xs",
                                    children: [
                                        "A",
                                        "B",
                                        "C",
                                        "D"
                                    ].map((opt)=>{
                                        const key = opt;
                                        const text = key === "A" ? currentQuestion.option_a : key === "B" ? currentQuestion.option_b : key === "C" ? currentQuestion.option_c : currentQuestion.option_d;
                                        if (!text) return null;
                                        const checked = answers[currentQuestion.id] === key;
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: `flex items-center gap-2 rounded-md border px-3 py-2 cursor-pointer ${checked ? "border-sky-500 bg-sky-500/10" : "border-slate-700 bg-slate-900"}`,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "radio",
                                                    name: `q-${currentQuestion.id}`,
                                                    className: "h-3 w-3",
                                                    checked: checked,
                                                    onChange: ()=>handleSelectAnswer(currentQuestion.id, key)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                    lineNumber: 703,
                                                    columnNumber: 25
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-semibold",
                                                    children: [
                                                        key,
                                                        "."
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                    lineNumber: 712,
                                                    columnNumber: 25
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: text
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                                    lineNumber: 713,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, key, true, {
                                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                            lineNumber: 695,
                                            columnNumber: 23
                                        }, this);
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                    lineNumber: 678,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                            lineNumber: 661,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-between items-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handlePrev,
                                    disabled: currentIndex === 0,
                                    className: "rounded-md bg-slate-800 px-3 py-1.5 text-xs font-medium text-white disabled:opacity-40",
                                    children: "← Indietro"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                    lineNumber: 722,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>handleFinish(false),
                                            className: "rounded-md bg-emerald-600 px-4 py-1.5 text-xs font-medium text-white",
                                            children: "Termina quiz"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                            lineNumber: 731,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: handleNext,
                                            disabled: currentIndex === totalQuestions - 1,
                                            className: "rounded-md bg-slate-800 px-3 py-1.5 text-xs font-medium text-white disabled:opacity-40",
                                            children: "Avanti →"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                            lineNumber: 737,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                                    lineNumber: 730,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                            lineNumber: 721,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
                    lineNumber: 633,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
            lineNumber: 502,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/quiz/[id]/custom/page.tsx",
        lineNumber: 501,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__355664eb._.js.map